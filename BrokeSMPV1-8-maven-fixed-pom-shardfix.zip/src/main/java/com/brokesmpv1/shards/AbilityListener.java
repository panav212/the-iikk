package com.brokesmpv1.shards;

import com.brokesmpv1.BrokeSMPV1;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.util.RayTraceResult;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * AbilityListener - FINAL
 *
 * - Passive and Hit remain automatic (unchanged).
 * - Kill ability: unlocked after 5 kills in a life. Activated with SHIFT + RIGHT-CLICK. Cooldown enforced.
 * - Extra ability (bought with essence): activated with SHIFT + LEFT-CLICK (attack while sneaking). Cooldown enforced.
 * - Cooldown feedback shown on the Action Bar (above XP bar).
 * - Kill progress increments on actual kills (onKill) and is reset after using Kill ability.
 */

public class AbilityListener implements Listener {

    private final BrokeSMPV1 plugin;

    // Keep cooldowns consistent with what we used before
    private static final long KILL_COOLDOWN_MS = 20_000L; // 20 seconds
    private static final long EXTRA_COOLDOWN_MS = 30_000L; // 30 seconds

    // Track last-used timestamps per-player
    private final Map<UUID, Long> killLastUsed = new ConcurrentHashMap<>();
    private final Map<UUID, Long> extraLastUsed = new ConcurrentHashMap<>();

    public AbilityListener(BrokeSMPV1 plugin) {
        this.plugin = plugin;
    }

    /**
     * Keep Passive + Hit behavior on normal hits.
     * Also detect SHIFT + LEFT-CLICK on-hit (attack while sneaking) to activate the Essence (Extra) ability.
     */
    @EventHandler
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player)) return;
        Player p = (Player) e.getDamager();
        Entity victim = e.getEntity();

        ShardType type = plugin.shards().getEquipped(p);
        if (type == null) return;

        int tier = plugin.shards().getTier(p);

        // Passive always
        if (tier >= 1) type.applyPassive(p);

        // Hit ability still triggers on normal hit
        if (tier >= 2) type.applyHit(p, victim);

        // EXTRA ability: SHIFT + LEFT-CLICK (attack while sneaking)
        // This captures the left-click attack while sneaking case.
        if (p.isSneaking() && plugin.shards().hasExtra(p)) {
            UUID id = p.getUniqueId();
            long now = System.currentTimeMillis();
            long last = extraLastUsed.getOrDefault(id, 0L);
            if (now - last >= EXTRA_COOLDOWN_MS) {
                // Activate extra ability on the victim
                type.applyExtra(p, victim);
                extraLastUsed.put(id, now);
                // Action bar feedback
                p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent("§a[Shard] Essence ability activated!"));
            } else {
                long remaining = (EXTRA_COOLDOWN_MS - (now - last)) / 1000;
                p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent("§c[Shard] Essence on cooldown: " + remaining + "s"));
            }
        }
    }

    /**
     * On kill: maintain kill progress (per-life). Do NOT auto-apply Kill or Extra here.
     */
    @EventHandler
    public void onKill(EntityDeathEvent e) {
        if (!(e.getEntity().getKiller() instanceof Player)) return;
        Player p = e.getEntity().getKiller();
        ShardType type = plugin.shards().getEquipped(p);
        if (type == null) return;

        // increment kill progress for the player (keeps original behavior)
        plugin.shards().addKillProgress(p);

        // No auto-apply of kill/extra here; activation is manual now.
    }

    /**
     * SHIFT + RIGHT-CLICK = Kill Ability activation (manual)
     */
    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        Action action = e.getAction();
        if (!(e.getPlayer() instanceof Player)) return;
        Player p = e.getPlayer();

        // We only care about right-click actions while sneaking
        if (!(action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK)) return;
        if (!p.isSneaking()) return;

        ShardType type = plugin.shards().getEquipped(p);
        if (type == null) return;
        int tier = plugin.shards().getTier(p);

        // Kill ability: requires tier >= 3 and 5 kills in this life
        if (tier >= 3 && plugin.shards().getKillProgress(p) >= 5) {
            UUID id = p.getUniqueId();
            long now = System.currentTimeMillis();
            long last = killLastUsed.getOrDefault(id, 0L);
            if (now - last >= KILL_COOLDOWN_MS) {
                // Try to find a target entity in front of the player (ray-trace up to 6 blocks)
                Entity target = null;
                try {
                    // Use getTargetEntity which exists across many versions
                    target = p.getTargetEntity(6);
                } catch (NoSuchMethodError ignored) {
                    // Older API: ignore and leave target null
                    target = null;
                } catch (Throwable ignored) {
                    target = null;
                }

                // Activate Kill ability
                type.applyKill(p, target);
                killLastUsed.put(id, now);

                // Reset kill progress after using the ability (common UX)
                try {
                    plugin.shards().resetKillProgress(p);
                } catch (Throwable ignored) {
                    // if reset method not present, try set to 0 if available
                    try { plugin.shards().resetKillProgress(p); } catch (Throwable ignored2) {}
                }

                p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent("§a[Shard] Kill ability activated!"));
            } else {
                long remaining = (KILL_COOLDOWN_MS - (now - last)) / 1000;
                p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent("§c[Shard] Kill ability on cooldown: " + remaining + "s"));
            }
        } else {
            // Optional: feedback when requirements not met (commented out to avoid spam)
            // if (tier < 3) p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent("§cYou need Tier 3 to use this."));
            // else p.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent("§cNeed 5 kills in this life to unlock."));
        }
    }
}
