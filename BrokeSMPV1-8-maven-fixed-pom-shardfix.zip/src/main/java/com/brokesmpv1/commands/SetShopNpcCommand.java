package com.brokesmpv1.commands;

import com.brokesmpv1.BrokeSMPV1;
import org.bukkit.Location;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class SetShopNpcCommand implements CommandExecutor {
    private final BrokeSMPV1 plugin;
    public SetShopNpcCommand(BrokeSMPV1 plugin){ this.plugin = plugin; }
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)){ sender.sendMessage("Players only."); return true; }
        if (!p.hasPermission("brokesmp.admin")){ p.sendMessage("§cNo permission."); return true; }
        Location loc = p.getLocation();
        plugin.npcs().spawnShopNpc(loc);
        p.sendMessage("§aSpawned §lShard Shop NPC §aat your location.");
        return true;
    }
}
